#ifndef EXAMEXTRA_PROBLEM1_H
#define EXAMEXTRA_PROBLEM1_H

int average(int a, int b);

float average(float a, float b);
float average(int a, float b);
float average(float a, int b);

double average(double a, double b);
double average(double a, int b);
double average(int a, double b);
double average(double a, float b);
double average(float a, double b);

#endif